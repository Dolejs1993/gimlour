## ----setup, include = FALSE---------------------------------------------------
library(gilmour)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----results='asis'-----------------------------------------------------------
knitr::kable(head(mtcars, 12))

